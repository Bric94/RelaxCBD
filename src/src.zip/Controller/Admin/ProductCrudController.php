<?php

namespace App\Controller\Admin;

use App\Entity\Product;
use Doctrine\ORM\EntityManagerInterface;
use EasyCorp\Bundle\EasyAdminBundle\Config\Crud;
use EasyCorp\Bundle\EasyAdminBundle\Controller\AbstractCrudController;
use EasyCorp\Bundle\EasyAdminBundle\Field\AssociationField;
use EasyCorp\Bundle\EasyAdminBundle\Field\BooleanField;
use EasyCorp\Bundle\EasyAdminBundle\Field\CollectionField;
use EasyCorp\Bundle\EasyAdminBundle\Field\ImageField;
use EasyCorp\Bundle\EasyAdminBundle\Field\IntegerField;
use EasyCorp\Bundle\EasyAdminBundle\Field\MoneyField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextareaField;
use EasyCorp\Bundle\EasyAdminBundle\Field\TextField;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\String\Slugger\SluggerInterface;

class ProductCrudController extends AbstractCrudController
{
    public function __construct(private SluggerInterface $slugger) {}

    public static function getEntityFqcn(): string
    {
        return Product::class;
    }

    public function configureFields(string $pageName): iterable
    {
        yield TextField::new('name', 'Nom du produit');
        yield MoneyField::new('price', 'Prix')->setStoredAsCents(false)->setCurrency('EUR');
        yield AssociationField::new('category', 'Catégorie')->setRequired(true);
        yield TextareaField::new('description')->setFormType(\FOS\CKEditorBundle\Form\Type\CKEditorType::class);
        yield BooleanField::new('isWeightBased', "Basé sur le poids (en grammes)");
        yield IntegerField::new('stock', 'Stock');
        yield ImageField::new('image', 'Image')
            ->setBasePath('/uploads/products')
            ->setUploadDir('public/uploads/products')
            ->setUploadedFileNamePattern('[randomhash].[extension]')
            ->setRequired(false);

        // INDEX (page listing) : N'utilise PAS ArrayField
        if ($pageName === Crud::PAGE_INDEX) {
            yield TextField::new('priceByWeight', 'Prix par poids')
                ->formatValue(static function ($value) {
                    if (empty($value) || !is_array($value)) {
                        return '-';
                    }
                    $count = count($value);
                    // Affiche exemple : "3 plages (1-4g, 5-9g...)"
                    $labels = array_map(function ($tranche) {
                        if (!is_array($tranche)) return '';
                        $min = $tranche['min'] ?? '';
                        $max = $tranche['max'] ?? '';
                        return $max !== '' ? "{$min}-{$max}g" : "{$min}+g";
                    }, $value);
                    return $count . ' plage(s) : ' . implode(', ', $labels);
                });
        }

        // DETAIL : affichage lisible (pas d'ArrayField non plus)
        if ($pageName === Crud::PAGE_DETAIL) {
            yield TextareaField::new('priceByWeight', 'Prix par poids')
                ->formatValue(static function ($value) {
                    if (empty($value) || !is_array($value)) return '-';
                    return implode("\n", array_map(static function ($tranche) {
                        $min = $tranche['min'] ?? '';
                        $max = $tranche['max'] ?? '';
                        $price = $tranche['price'] ?? '';
                        return $max !== '' ? "{$min}-{$max}g : {$price}€/g" : "{$min}+g : {$price}€/g";
                    }, $value));
                });
        }

        // FORM : CollectionField pour éditer/ajouter les tranches (ça c'est OK !)
        if ($pageName === Crud::PAGE_NEW || $pageName === Crud::PAGE_EDIT) {
            yield CollectionField::new('priceByWeight', 'Prix par poids')
                ->setEntryType(\App\Form\PriceByWeightItemType::class)
                ->allowAdd()
                ->allowDelete()
                ->setHelp('Ajoutez des plages (ex : 1-4g:10€/g, 5-9g:9€/g...)');
        }
    }

    private function uploadImage(UploadedFile $file): string
    {
        $originalFilename = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $safeFilename = $this->slugger->slug($originalFilename);
        $newFilename = $safeFilename . '-' . uniqid() . '.' . $file->guessExtension();
        $file->move('public/uploads/products', $newFilename);
        return $newFilename;
    }

    public function persistEntity(EntityManagerInterface $entityManager, $entityInstance): void
    {
        if ($entityInstance instanceof Product) {
            $priceByWeight = $entityInstance->getPriceByWeight();
            if (is_array($priceByWeight) && isset($priceByWeight['prices'])) {
                $entityInstance->setPriceByWeight($priceByWeight['prices']);
            }
        }

        $imageFile = $this->getContext()->getRequest()->files->get('Product')['imageFile'] ?? null;
        if ($imageFile instanceof UploadedFile) {
            $newFilename = $this->uploadImage($imageFile);
            $entityInstance->setImage($newFilename);
        }

        $entityManager->persist($entityInstance);
        $entityManager->flush();
    }

    public function updateEntity(EntityManagerInterface $entityManager, $entityInstance): void
    {
        if ($entityInstance instanceof Product) {
            $priceByWeight = $entityInstance->getPriceByWeight();
            if (is_array($priceByWeight) && isset($priceByWeight['prices'])) {
                $entityInstance->setPriceByWeight($priceByWeight['prices']);
            }
        }

        $entityManager->persist($entityInstance);
        $entityManager->flush();
    }
}
